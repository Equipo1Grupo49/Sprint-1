/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mintic.edu.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Esta clase establece la conexion a la base de datos
 * @authors
 */

// 
public class Conexion {
    private Connection con;
    private Statement consulta;
    private static final String URL = "jdbc:mysql://localhost:3305/proyecto";
    private static final String USER = "root";
    private static final String PASS = "admin";
    
    
    public Connection Conexion(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(URL, USER, PASS);
            consulta = con.createStatement();
            if(con != null){
                System.out.println("Conectados a la Base de Datos");
            }
        }catch(ClassNotFoundException | SQLException e){
                System.out.println("Error"+e.getMessage());
    }
    return con;
    }   
}
