/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mintic.edu.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author arcab
 */
public class UsuarioDAO {
    // Definir los Atributos. Capa de Datos. Se comunica con la BDs
    Connection con = null; // Hacer la conexion a la BDs
    Conexion cn = new Conexion();
    Statement stm = null; // Separa el espacio para construir un comando SQL
    ResultSet res = null; // Atributo para guardar el resultado de la consulta
    PreparedStatement ps = null; // Atributo para la consulta SQL precompilada


        public String login(Usuario pUsuario) {
        String estado = "";
        ResultSet rs;
        try 
        {
            con = cn.Conexion();
            String sql = "select tipoUsuario, email from usuario where usuario=? and clave=?";
            ps =con.prepareStatement(sql);
            ps.setString(1, pUsuario.getUsuario());
            ps.setString(2, pUsuario.getClave());
            rs= ps.executeQuery();
            if (rs.next()) {
                estado = "true";
            }
            pUsuario.setTipoUsuario(rs.getString("tipoUsuario"));
            pUsuario.setEmail(rs.getString("email"));
        } catch (Exception e) {
            System.err.println("Error:" + e);
        }
        return estado;
    }
        public List<Usuario> getUsuarios() {
        String sql = "SELECT * FROM usuario";

        List<Usuario> usuarios = new ArrayList<>();

        try {
            con = cn.Conexion();
            stm = con.createStatement(); 
            res = stm.executeQuery(sql);
            while (res.next()) { // Recorrer todo el ResultSet
                Usuario usu = new Usuario(); // Instanciamos un objeto tipo Usuario
                usu.setCedula(res.getInt(1));
                usu.setNombre(res.getString(2));
                usu.setUsuario(res.getString(3));
                usu.setClave(res.getString(4));
                usu.setEmail(res.getString(5));
                usu.setTipoUsuario(res.getString(6));
                usuarios.add(usu); // Agregarlo al ArrayList
            }
            stm.close(); // Cerrar toda la conexión a la BDs
            res.close();
            con.close();
        } catch (SQLException e) {
            System.err.println("Error:" + e);
        }
        return usuarios; // Devuelve el ArrayList usuarios
    }
}
